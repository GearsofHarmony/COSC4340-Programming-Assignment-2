#include <GL/glut.h>
#include <cmath>

void drawPolygon(float x_origin, float y_origin, int size, int vertices) {
	glBegin(GL_LINE_LOOP);
	glColor3f(0.0, 0.0, 0.0); //default color to black
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawPolygon(float x_origin, float y_origin, int size, int vertices, float colorRed, float colorGreen, float colorBlue) {
	glBegin(GL_LINE_LOOP);
	glColor3f(colorRed, colorGreen, colorBlue);
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawFilledPolygon(float x_origin, float y_origin, int size, int vertices) {
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 0.0); //default color to black
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawFilledPolygon(float x_origin, float y_origin, int size, int vertices, float colorRed, float colorGreen, float colorBlue) {
	glBegin(GL_POLYGON);
	glColor3f(colorRed, colorGreen, colorBlue);
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawCircle(float x_origin, float y_origin, int size) {
	glBegin(GL_LINE_LOOP);
	glColor3f(0.0, 0.0, 0.0); //default color to black
	int vertices = 10000;
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawCircle(float x_origin, float y_origin, int size, float colorRed, float colorGreen, float colorBlue) {
	glBegin(GL_LINE_LOOP);
	glColor3f(colorRed, colorGreen, colorBlue);
	int vertices = 10000;
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawFilledCircle(float x_origin, float y_origin, int size) {
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 0.0); //default color to black
	int vertices = 10000;
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void drawFilledCircle(float x_origin, float y_origin, int size, float colorRed, float colorGreen, float colorBlue) {
	glBegin(GL_POLYGON);
	glColor3f(colorRed, colorGreen, colorBlue);
	int vertices = 10000;
	float angle = 2 * 3.14 / vertices;

	for (int i = 0; i < vertices; i++) {
		GLfloat x = x_origin + size * sin(i * angle);
		GLfloat y = y_origin + size * cos(i * angle);
		glVertex2f(x, y);
	}

	glEnd();
}

void clearPolygon(float xPos, float yPos, int size) {
	glEnable(GL_SCISSOR_TEST);
	glScissor(xPos - size, yPos - size, size * 2, size * 2); //adjust area from center to bottom left
	glClear(GL_COLOR_BUFFER_BIT); //Clear area
	glDisable(GL_SCISSOR_TEST);
}
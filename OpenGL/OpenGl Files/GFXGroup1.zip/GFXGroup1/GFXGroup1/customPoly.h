#pragma once
#include <list>

using namespace std;

class Point {
private:
	float xPos;
	float yPos;
public:
	Point(float x, float y);
	float getXPos() { return xPos; }
	float getYPos() { return yPos; }
	void setXPos(float x) { xPos = x; }
	void setYPos(float y) { yPos = y; }
};

class CustomPoly
{
private:
	bool completed; //contains whether or not the polygon has been finished/all the points have been added
	float rotationAngle;
	list<Point> points; //the list of points in the polygon
	Point center = Point(0, 0);
	void recenter();
public:
	CustomPoly();
	void addPoint(float x, float y);
	void displayPoints();
	void displayPolygon();
	bool isFirstPoint(float xPos, float yPos);
	void scalePoly(float scale_x, float scale_y);
	void transPoly(float transX, float transY);
	void rotatePoly();
	void changeRotationDirection();
	bool isCompleted() { return completed; }
	list<Point> getPoints() { return points; }
	void setCompleted(bool c) { completed = c; }
	void setRotationAngle(float input) { rotationAngle = input; }
	float getRotationAngle() { return rotationAngle; }
	int numPoints() { return points.size(); }
};


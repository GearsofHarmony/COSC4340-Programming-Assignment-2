#include "customPoly.h"
#include "drawingTools.h"
#include<GL/glut.h>
#include <math.h>
#include <iostream>

//-------------Point constructor

Point::Point(float x, float y) {
	xPos = x;
	yPos = y;
}

//-------------Custom Poly Functions

//default (and only) constructor
CustomPoly::CustomPoly() {
	completed = false;
	rotationAngle = .1;
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    2/29/2020
	--addPoint(float x, float y)--
	Checks to see if the polygon is completed. If not, adds a point to the list
	and displays a circle to represent its location
*/
void CustomPoly::addPoint(float x, float y) {
	if (!completed) {
		points.push_back(Point(x, y)); //add point to the list
		if (points.size() == 1) { //if that was the first point
			drawFilledCircle(x, y, 10, 1, 0, 0); //draw a red circle to signify it
		}
		else {
			drawFilledCircle(x, y, 10); //display a black one
		}
	}
	else {
		cout << "Can't add more points when the polygon has been completed!\n";
	}
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    2/29/2020
	--displayPoints()--
	For use with debugging help. Outputs (to the console) the coordinates of every point that currently
	exists within the list
*/
void CustomPoly::displayPoints() {
	list<Point> tempList = points;
	if (!tempList.empty()) { //so long as the list isn't empty
		cout << "Points:-------------------------------------\n";
		while (!tempList.empty()) {
			cout << "(" << tempList.front().getXPos() << ", " << tempList.front().getYPos() << ")\n";
			tempList.pop_front();
		}
	}
	else {
		cout << "There are currently no points in the polygon.\n";
	}
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    2/29/2020
	--displayPolygon()--
	Displays the polygon using all of the points accumulated in the list
*/
void CustomPoly::displayPolygon() {
	list<Point> tempList = points;

	glClear(GL_COLOR_BUFFER_BIT); //Clear canvas first
	glBegin(GL_TRIANGLE_FAN);
	glColor3f(0.0, 0.0, 0.0); //default color to black

	while (!tempList.empty()) { //go through the list and add all the points
		glVertex2f(tempList.front().getXPos(), tempList.front().getYPos());
		tempList.pop_front();
	}

	glEnd();
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    2/29/2020
	--isFirstPoint(float x, float y)--
	Checks to see if a given point is within the display of the first point. "Within" is considered to be
	anywhere within the displayed circle.
*/
bool CustomPoly::isFirstPoint(float x, float y) {
	//distance formula between input and the first point of the list
	float distance = sqrt(pow(points.front().getXPos() - x, 2) + pow(points.front().getYPos() - y, 2));

	if (distance <= 10) { //result of distance formula
		recenter(); //set the initial value for the center of the polygon
		return true;
	}
	else {
		return false;
	}
}

/*
	Author:        Katie Easlon
				COSC 4332 01
	Edit Date:    3/3/2020
	scalePoly(): Scales and moves the Polygon according to the new scaled points
*/
void CustomPoly::scalePoly(float scale_x, float scale_y)
{

	list<Point> orig = points; //Temp to helo with list manipulation 

	float x, y, ratio_x, ratio_y = 0; //x and y are the new points where ratio_x and ratio_y are what the old points are multipled by

	ratio_x = scale_x / orig.front().getXPos(); //sets the ratio for x
	ratio_y = scale_y / orig.front().getYPos();    //sets the ratio for y

	for (int i = 0; i < points.size(); i++) //Scales the old points to the new values
	{
		x = ratio_x * orig.front().getXPos(); //Sets x to the new value
		y = ratio_y * orig.front().getYPos(); // Sets y to the new value

		//Manipulate the temp list
		orig.pop_front();
		orig.push_back(Point(x, y));

		//Manipulate the real list
		points.pop_front();
		points.push_back(Point(x, y));

		//Set both to zero for the next itteration of the for loop
		x = 0;
		y = 0;
	}
	
	recenter(); //points have changed, get the new center
}

void CustomPoly::transPoly(float transX, float transY)
{
	list<Point> temp = points;

	float x_prime, y_prime = 0;

	float x, y = 0;

	x = transX - temp.front().getXPos();
	y = transY - temp.front().getYPos();

	for (int k = 0; k < points.size(); k++)
	{
		x_prime = x + temp.front().getXPos();
		y_prime = y + temp.front().getYPos();

		temp.pop_front();
		temp.push_back(Point(x_prime, y_prime));
		points.pop_front();
		points.push_back(Point(x_prime, y_prime));

		x_prime, y_prime = 0;
	}

	recenter(); //points changed, re-calculate the center
}

/*
	Author:     Josh ???
				COSC 4332 01
	Edit Date:    3/5/2020
	--recenter()--
	Averages all of the points and determines the current center of the polygon
*/
void CustomPoly::recenter() // call every time you change the points of the polygon
{
	float centerX = 0.0f;
	float centerY = 0.0f;
	for (int ii = 0; ii < points.size(); ii++)
	{
		centerX += points.front().getXPos();
		centerY += points.front().getYPos();

		points.push_back(Point(points.front().getXPos(), points.front().getYPos()));
		points.pop_front();
	}

	centerX /= points.size();
	centerY /= points.size();

	center.setXPos(centerX);
	center.setYPos(centerY);
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    3/6/2020
	--rotatePoly()--
	Rotates the polygon based on the rotationAngle property. rotationAngle measured in radians
*/
void CustomPoly::rotatePoly()
{
	for (int ii = 0; ii < points.size(); ii++) //iterate through the list
	{
		//apply some math that i found in cooper's powerpoint
		float newX = center.getXPos() + (points.front().getXPos() - center.getXPos()) * cos(rotationAngle) - (points.front().getYPos() - center.getYPos()) * sin(rotationAngle);
		float newY = center.getYPos() + (points.front().getXPos() - center.getXPos()) * sin(rotationAngle) + (points.front().getYPos() - center.getYPos()) * cos(rotationAngle);

		//remove the front of the list, which we've now modified, and push it to the back
		points.pop_front();
		points.push_back(Point(newX, newY));
		//results in all points back in order but with modified values
	}

	void recenter(); //points changed, re-calculate the center
}

/*
	Author:     Zach Kucharz
				COSC 4332 01
	Edit Date:    3/6/2020
	--changeRotationDirection()--
	Flips the direction of the current rotationAngle value. Will appear to rotate clockwise/counterclockwise
	with each consecutive call.
*/
void CustomPoly::changeRotationDirection() {
	rotationAngle = rotationAngle * -1; //this is all its doing lol
}
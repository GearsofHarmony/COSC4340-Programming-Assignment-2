void drawPolygon(float x_origin, float y_origin, int size, int vertices);
void drawPolygon(float x_origin, float y_origin, int size, int vertices, float colorRed, float colorGreen, float colorBlue);
void drawFilledPolygon(float x_origin, float y_origin, int size, int vertices);
void drawFilledPolygon(float x_origin, float y_origin, int size, int vertices, float colorRed, float colorGreen, float colorBlue);
void drawCircle(float x_origin, float y_origin, int size);
void drawCircle(float x_origin, float y_origin, int size, float colorRed, float colorGreen, float colorBlue);
void drawFilledCircle(float x_origin, float y_origin, int size);
void drawFilledCircle(float x_origin, float y_origin, int size, float colorRed, float colorGreen, float colorBlue);
void clearPolygon(float xPos, float yPos, int size);
#include <GL/glut.h>
#include "drawingTools.h"
#include "customPoly.h"
#include <iostream>

CustomPoly poly = CustomPoly(); //object instantiation, i hate global vars but openGL sucks
int rotateTimer = 0;

void init(void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0); // Set display-window color to white.
    glMatrixMode(GL_PROJECTION); // Set projection parameters.
    gluOrtho2D(0, 600, 400, 0);
}

void mouseClick(int button, int state, int xPos, int yPos) {

    if (!poly.isCompleted()) { //handling for before the polygon is drawn
        if (state == GLUT_DOWN) {
            if (poly.numPoints() != 0 && poly.isFirstPoint(xPos, yPos)) { //if they clicked within the first point, draw the polygon
                poly.displayPolygon();
                poly.setCompleted(true);
            }
            else { //add a point and display its position on the screen
                poly.addPoint(xPos, yPos);
            }
        } //end if state
    }
    else { //the polygon has already been drawn, so the click is for transforming it
        if (state == GLUT_DOWN) { //make sure it's only on the down press
            switch (glutGetModifiers()) { //call different methods depending on the click
            case GLUT_ACTIVE_SHIFT:
                poly.scalePoly(xPos, yPos);
                poly.displayPolygon();
                break;
            case GLUT_ACTIVE_ALT:
                poly.changeRotationDirection();
                break;
            default:
                poly.transPoly(xPos, yPos);
                poly.displayPolygon();
                break;
            }
        }
    }
}

void render(void)
{
    if (poly.isCompleted() && rotateTimer == 10000) {
        poly.rotatePoly();
        poly.displayPolygon();
        rotateTimer = 0;
    }
    else if (poly.isCompleted()){
        rotateTimer++;
    }
    
    glFlush(); // Process all OpenGL routines as quickly as possible.
    glutPostRedisplay();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv); // Initialize GLUT.
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // Set display mode.
    glutInitWindowPosition(50, 100); // Set top-left display-window position.
    glutInitWindowSize(600, 400); // Set display-window width and height.
    glutCreateWindow("Draw and Transform"); // Create display window.
    init(); // Execute initialization procedure.
    glutDisplayFunc(render); // Send graphics to display window.
    glutMouseFunc(mouseClick);
    glutMainLoop(); // Display everything and wait.
}